package com.example.oxidelauncher;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView btnAddPlugin = findViewById(R.id.btnAddPlugin);
        TextView btnLaunch = findViewById(R.id.btnLaunch);

        // Пустышка: кнопки пока не делают ничего, кроме показа тач-эффекта (волны)
        btnAddPlugin.setOnClickListener(v ->
                Toast.makeText(this, "Это макет — функционал ещё не подключён", Toast.LENGTH_SHORT).show());

        btnLaunch.setOnClickListener(v ->
                Toast.makeText(this, "Это макет — функционал ещё не подключён", Toast.LENGTH_SHORT).show());
    }
}
